import React, { useState } from 'react';
import { User } from '../types';
import PatientDashboard from './PatientDashboard';
import PhysicianDashboard from './PhysicianDashboard';
import { Brain, Stethoscope } from 'lucide-react';

interface DashboardProps {
  user: User;
}

export default function Dashboard({ user }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              {user.role === 'physician' ? (
                <Stethoscope className="h-8 w-8 text-blue-600" />
              ) : (
                <Brain className="h-8 w-8 text-blue-600" />
              )}
              <span className="ml-2 text-xl font-semibold text-gray-900">
                HealthConnect AI
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-500">Welcome, {user.name}</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {user.role === 'patient' ? (
          <PatientDashboard user={user} />
        ) : (
          <PhysicianDashboard user={user} />
        )}
      </main>
    </div>
  );
}