import React from 'react';
import { User } from '../types';
import { Users, ClipboardList, MessageSquare, Brain } from 'lucide-react';

interface PhysicianDashboardProps {
  user: User;
}

export default function PhysicianDashboard({ user }: PhysicianDashboardProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <DashboardCard
          icon={<Users className="h-6 w-6 text-blue-600" />}
          title="Patients"
          description="Manage your patient list"
        />
        <DashboardCard
          icon={<ClipboardList className="h-6 w-6 text-green-600" />}
          title="Clinical Data"
          description="Review patient records"
        />
        <DashboardCard
          icon={<MessageSquare className="h-6 w-6 text-purple-600" />}
          title="Messages"
          description="Patient communications"
        />
        <DashboardCard
          icon={<Brain className="h-6 w-6 text-indigo-600" />}
          title="AI Insights"
          description="AI-powered clinical support"
        />
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">
          Today's Appointments
        </h2>
        <div className="border-t border-gray-200 pt-4">
          <p className="text-gray-500 text-sm">No appointments scheduled for today</p>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">
          Recent Patient Updates
        </h2>
        <div className="border-t border-gray-200 pt-4">
          <p className="text-gray-500 text-sm">No recent updates</p>
        </div>
      </div>
    </div>
  );
}

function DashboardCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">{icon}</div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd className="text-sm text-gray-900">{description}</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}