import React from 'react';
import { MessageCircle } from 'lucide-react';

interface SuggestedPromptsProps {
  onPromptClick: (prompt: string) => void;
}

const prompts = [
  "I need a prescription refill",
  "I'm experiencing new symptoms",
  "I want to discuss my chronic condition",
  "I need urgent medical advice"
];

export function SuggestedPrompts({ onPromptClick }: SuggestedPromptsProps) {
  return (
    <div className="p-4 border-t bg-gray-50">
      <div className="flex items-center space-x-2 mb-2">
        <MessageCircle className="h-4 w-4 text-gray-500" />
        <span className="text-sm text-gray-500">Suggested topics</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {prompts.map((prompt, index) => (
          <button
            key={index}
            onClick={() => onPromptClick(prompt)}
            className="px-3 py-1 bg-white border rounded-full text-sm text-gray-700 hover:bg-gray-100 transition-colors"
          >
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}