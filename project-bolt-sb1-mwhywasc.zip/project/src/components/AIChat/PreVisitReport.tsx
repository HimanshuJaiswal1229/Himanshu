import React from 'react';
import { X, Download, Send } from 'lucide-react';

interface PreVisitReportProps {
  onClose: () => void;
  messages: Array<{ role: 'user' | 'bot', content: string }>;
}

export function PreVisitReport({ onClose, messages }: PreVisitReportProps) {
  const handleSendToDoctor = () => {
    // Logic to send report to doctor would go here
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-semibold">Pre-Visit Report</h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium">Summary</h4>
            <p className="text-gray-600">
              Patient reports symptoms related to [condition]. Primary concerns include [symptoms].
              Duration of symptoms: [timeframe].
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Key Points</h4>
            <ul className="list-disc list-inside text-gray-600 space-y-1">
              <li>Symptom onset and progression</li>
              <li>Current medications and allergies</li>
              <li>Previous relevant medical history</li>
              <li>Impact on daily activities</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="font-medium">Conversation History</h4>
            <div className="max-h-40 overflow-y-auto border rounded-md p-3 bg-gray-50">
              {messages.map((message, index) => (
                <div key={index} className="mb-2">
                  <span className="font-medium">{message.role === 'user' ? 'Patient: ' : 'Assistant: '}</span>
                  {message.content}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3 p-4 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSendToDoctor}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Send className="h-4 w-4" />
            <span>Send to Doctor</span>
          </button>
        </div>
      </div>
    </div>
  );
}