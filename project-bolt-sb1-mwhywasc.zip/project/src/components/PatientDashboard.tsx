import React, { useState } from 'react';
import { User } from '../types';
import { Activity, Calendar, MessageSquare, Pill as Pills } from 'lucide-react';
import ChatBot from './AIChat/ChatBot';

interface PatientDashboardProps {
  user: User;
}

export default function PatientDashboard({ user }: PatientDashboardProps) {
  const [showChatBot, setShowChatBot] = useState(false);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <DashboardCard
          icon={<Activity className="h-6 w-6 text-blue-600" />}
          title="Vital Signs"
          description="Track your health metrics"
        />
        <DashboardCard
          icon={<Pills className="h-6 w-6 text-green-600" />}
          title="Medications"
          description="View your current medications"
        />
        <DashboardCard
          icon={<Calendar className="h-6 w-6 text-purple-600" />}
          title="Appointments"
          description="Schedule and manage appointments"
        />
        <button
          onClick={() => setShowChatBot(true)}
          className="focus:outline-none"
        >
          <DashboardCard
            icon={<MessageSquare className="h-6 w-6 text-indigo-600" />}
            title="AI Health Assistant"
            description="Get help and create pre-visit reports"
          />
        </button>
      </div>

      {showChatBot && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-4xl">
            <ChatBot />
          </div>
        </div>
      )}

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">
          Upcoming Appointments
        </h2>
        <div className="border-t border-gray-200 pt-4">
          <p className="text-gray-500 text-sm">No upcoming appointments</p>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">
          Recent Messages
        </h2>
        <div className="border-t border-gray-200 pt-4">
          <p className="text-gray-500 text-sm">No recent messages</p>
        </div>
      </div>
    </div>
  );
}

function DashboardCard({ icon, title, description }: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0">{icon}</div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd className="text-sm text-gray-900">{description}</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}