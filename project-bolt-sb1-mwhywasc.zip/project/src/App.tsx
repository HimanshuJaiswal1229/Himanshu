import React from 'react';
import Dashboard from './components/Dashboard';
import { User } from './types';

function App() {
  // Mock user for demonstration
  const mockUser: User = {
    id: '1',
    role: 'physician',
    name: 'Dr. Himanshu Jaiswal',
    email: 'himanshu.jaiswal@example.com'
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Dashboard user={mockUser} />
    </div>
  );
}

export default App;