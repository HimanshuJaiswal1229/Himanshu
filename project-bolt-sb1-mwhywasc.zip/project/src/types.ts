export interface User {
  id: string;
  role: 'patient' | 'physician';
  name: string;
  email: string;
}

export interface ClinicalData {
  id: string;
  patientId: string;
  date: string;
  symptoms: string[];
  notes: string;
  vitals: {
    bloodPressure: string;
    heartRate: number;
    temperature: number;
  };
}

export interface Therapy {
  id: string;
  patientId: string;
  physicianId: string;
  name: string;
  description: string;
  startDate: string;
  endDate?: string;
  status: 'active' | 'completed' | 'cancelled';
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}